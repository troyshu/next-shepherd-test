export default function DayPage() {
  return <div>Hello Day</div>
}
